package com.reportlyai.app

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 24, 40)
    private val blue = Color.rgb(45, 106, 227)
    private val ink = Color.rgb(31, 41, 55)
    private val muted = Color.rgb(107, 114, 128)
    private val line = Color.rgb(229, 231, 235)
    private val prefs by lazy { getSharedPreferences("reportly", Context.MODE_PRIVATE) }
    private lateinit var typeSpinner: Spinner
    private lateinit var detailsInput: EditText
    private lateinit var locationInput: EditText
    private lateinit var dateInput: EditText
    private lateinit var output: EditText
    private lateinit var historyBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,248,252)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(20)); setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply { text = "REPORTLY AI"; textSize = 12f; letterSpacing = .16f; setTextColor(Color.rgb(157,190,255)); setTypeface(null, Typeface.BOLD) })
        header.addView(TextView(this).apply { text = "Work reports, made simple."; textSize = 25f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); setPadding(0, dp(8), 0, dp(5)) })
        header.addView(TextView(this).apply { text = "Turn quick notes into clear, professional reports."; textSize = 14f; setTextColor(Color.rgb(213,220,233)) })
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(28)) }
        scroll.addView(content)
        content.addView(label("CREATE A REPORT"))
        content.addView(card().also { card ->
            val inner = card
            inner.addView(label("Report type"))
            typeSpinner = Spinner(this)
            val types = arrayOf("Security incident", "Maintenance update", "Daily activity report", "Shift handover")
            typeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
            inner.addView(typeSpinner, matchWrap())
            inner.addView(label("Location / area"))
            locationInput = edit("e.g. Third floor corridor", false)
            inner.addView(locationInput, matchWrap())
            inner.addView(label("What happened?"))
            detailsInput = edit("Write your rough notes here...", true)
            inner.addView(detailsInput, LinearLayout.LayoutParams(-1, dp(112)))
            inner.addView(label("Date and time (optional)"))
            dateInput = edit("e.g. 28/10/2026, 10:30 AM", false)
            inner.addView(dateInput, matchWrap())
            val generate = button("Generate professional report", blue)
            inner.addView(generate, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(16) })
            generate.setOnClickListener { generateReport() }
        })

        content.addView(label("YOUR REPORT"))
        content.addView(card().also { c ->
            output = edit("Your finished report will appear here.", true).apply { minHeight = dp(145); isFocusable = true }
            c.addView(output, LinearLayout.LayoutParams(-1, dp(165)))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val copy = button("Copy report", navy)
            val share = button("Share", blue)
            row.addView(copy, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
            row.addView(share, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
            c.addView(row, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
            copy.setOnClickListener { copyReport() }
            share.setOnClickListener { shareReport() }
        })

        content.addView(label("RECENT REPORTS"))
        content.addView(card().also { c ->
            historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c.addView(historyBox, matchWrap())
            val clear = TextView(this).apply { text = "Clear history"; textSize = 13f; setTextColor(blue); gravity = Gravity.END; setPadding(0, dp(14), 0, 0) }
            c.addView(clear, matchWrap())
            clear.setOnClickListener { prefs.edit().remove("history").apply(); refreshHistory() }
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHistory()
    }

    private fun generateReport() {
        val type = typeSpinner.selectedItem.toString()
        val details = detailsInput.text.toString().trim()
        val location = locationInput.text.toString().trim()
        val date = dateInput.text.toString().trim()
        if (details.isBlank()) { detailsInput.error = "Enter a few details first"; detailsInput.requestFocus(); return }
        val area = if (location.isNotBlank()) " at $location" else ""
        val time = if (date.isNotBlank()) " ( $date )" else ""
        val cleaned = details.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }.trimEnd('.', ' ')
        val report = when (type) {
            "Security incident" -> "SECURITY INCIDENT REPORT\n\nDate/Time: ${date.ifBlank { "Not specified" }}\nLocation: ${location.ifBlank { "Not specified" }}\n\nDetails: $cleaned.\n\nAction Taken: ${inferAction(details)}\n\nReported for record and necessary follow-up."
            "Maintenance update" -> "MAINTENANCE UPDATE\n\nDate/Time: ${date.ifBlank { "Not specified" }}\nLocation: ${location.ifBlank { "Not specified" }}\n\nUpdate: $cleaned.\n\nStatus: ${inferStatus(details)}\n\nPlease follow up as required."
            "Daily activity report" -> "DAILY ACTIVITY REPORT$time\n\nArea: ${location.ifBlank { "Not specified" }}\n\nActivities / Observations:\n$cleaned.\n\nThis report is submitted for record."
            else -> "SHIFT HANDOVER REPORT$time\n\nLocation: ${location.ifBlank { "Not specified" }}\n\nHandover Notes:\n$cleaned.\n\nPlease review the above information and continue any required follow-up."
        }
        output.setText(report)
        saveHistory(type, location, report)
        Toast.makeText(this, "Report generated", Toast.LENGTH_SHORT).show()
    }

    private fun inferAction(s: String): String {
        val t = s.lowercase()
        return when {
            "inform" in t || "notified" in t || "reported" in t -> "The relevant team/supervisor was informed, as noted."
            "maintenance" in t || "technician" in t -> "Maintenance follow-up was noted."
            "fire" in t || "alarm" in t -> "The matter should be handled according to site emergency procedures."
            else -> "The matter was documented for supervisor review. Add the action taken if applicable."
        }
    }
    private fun inferStatus(s: String): String {
        val t = s.lowercase()
        return when {
            "fixed" in t || "completed" in t || "repaired" in t -> "Work reported as completed."
            "working" in t || "cleaning" in t || "repair" in t -> "Work is in progress, based on the notes provided."
            "pending" in t || "not working" in t || "leak" in t -> "Requires follow-up; confirm the current status with the responsible team."
            else -> "Status not specified; confirm with the responsible team."
        }
    }

    private fun saveHistory(type: String, location: String, report: String) {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().put("type", type).put("location", location).put("report", report)
        val next = JSONArray().put(item)
        for (i in 0 until minOf(arr.length(), 9)) next.put(arr.getJSONObject(i))
        prefs.edit().putString("history", next.toString()).apply()
        refreshHistory()
    }

    private fun refreshHistory() {
        if (!::historyBox.isInitialized) return
        historyBox.removeAllViews()
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            historyBox.addView(TextView(this).apply { text = "Your saved reports will appear here."; textSize = 14f; setTextColor(muted); setPadding(0, dp(4), 0, dp(4)) })
            return
        }
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val row = TextView(this).apply {
                text = "${item.optString("type")}\n${item.optString("location").ifBlank { "No location"}}"
                textSize = 14f; setTextColor(ink); setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { output.setText(item.optString("report")); Toast.makeText(this@MainActivity, "Report loaded", Toast.LENGTH_SHORT).show() }
            }
            historyBox.addView(row, matchWrap())
            if (i < arr.length() - 1) historyBox.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun copyReport() {
        val text = output.text.toString().trim()
        if (text.isBlank() || text == "Your finished report will appear here.") { Toast.makeText(this, "Generate a report first", Toast.LENGTH_SHORT).show(); return }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Reportly report", text))
        Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
    }
    private fun shareReport() {
        val text = output.text.toString().trim()
        if (text.isBlank() || text == "Your finished report will appear here.") { Toast.makeText(this, "Generate a report first", Toast.LENGTH_SHORT).show(); return }
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text) }
        startActivity(android.content.Intent.createChooser(intent, "Share report"))
    }

    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 11f; letterSpacing = .12f; setTextColor(muted); setTypeface(null, Typeface.BOLD); setPadding(dp(2), dp(17), dp(2), dp(9)) }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(Color.WHITE, dp(16), line, dp(1))
        layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(3) }
    }
    private fun edit(hintText: String, multi: Boolean): EditText = EditText(this).apply {
        hint = hintText; textSize = 15f; setTextColor(ink); setHintTextColor(Color.rgb(156,163,175)); setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(Color.rgb(249,250,251), dp(10), line, dp(1))
        if (multi) { gravity = Gravity.TOP or Gravity.START; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        else inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        if (multi) setSingleLine(false) else setSingleLine(true)
    }
    private fun button(textValue: String, color: Int) = TextView(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        background = rounded(color, dp(11), color, 0)
    }
    private fun rounded(color: Int, radius: Int, stroke: Int, strokeWidth: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); if (strokeWidth > 0) setStroke(strokeWidth, stroke) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
