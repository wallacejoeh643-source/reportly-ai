# Reportly AI — Android starter app

A native Android prototype for generating professional security, maintenance, daily activity, and shift-handover reports. It uses on-device templates; it does not call a paid AI API or send report text to a server.

## Build APK in GitHub Actions
1. Create a free GitHub account and a new repository named `reportly-android`.
2. Upload the contents of this folder to the repository (keep the `.github/workflows/build-apk.yml` file and its folder).
3. Open the repository's **Actions** tab and choose **Build Reportly AI APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When the run finishes, open it and download the `reportly-ai-debug-apk` artifact. Extract the ZIP to get `app-debug.apk`.
6. Open the APK on your Android phone and approve installation from that source if Android asks.

This is a prototype debug APK, not a Play Store release. Before commercial release, add a production signing key, privacy policy, testing, and a plan for support and updates.
